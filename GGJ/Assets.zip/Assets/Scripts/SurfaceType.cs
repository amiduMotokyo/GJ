public enum SurfaceType
{
    Dry,            // 干燥表面
    Wet,            // 湿润表面
    Dangerous       // 危险表面（会导致泡泡破裂）
}
