using System.Collections;
using System.Collections.Generic;
using Cinemachine;
using UnityEngine;
using UnityEngine.UIElements;

public class CameraController : MonoBehaviour
{
    [SerializeField] private GameObject _player;//���ڻ�ȡ������壬ʹ�����λ���������
    [SerializeField] private CinemachineVirtualCamera _virtualCamera;//��ȡ���
    [SerializeField] private GameObject _cameraBound;//��ȡÿ������������߽�
    [SerializeField] private CinemachineConfiner2D _confiner;//�߽��޶����

    private void Awake()
    {
        _virtualCamera = GetComponent<CinemachineVirtualCamera>();
        _confiner = GetComponent<CinemachineConfiner2D>();
    }

    private void Update()
    {
        if(_player == null)
        {
            REF();
        }
    }

    public void REF()
    {
        _player = GameObject.FindWithTag("player");
        _cameraBound = GameObject.Find("CameraBounds").gameObject;
        _virtualCamera.Follow = _player.transform;
        _confiner.m_BoundingShape2D = _cameraBound.GetComponent<PolygonCollider2D>();
    }
}
