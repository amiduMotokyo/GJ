using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickStart : MonoBehaviour
{
    /// <summary>
    /// �����Start
    /// </summary>
    public void OnClick()
    {
        Debug.Log("�����Start");
    }
}
