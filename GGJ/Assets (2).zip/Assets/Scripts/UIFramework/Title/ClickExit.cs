using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickExit : MonoBehaviour      
{
    /// <summary>
    /// �����Exit
    /// </summary>
    public void OnClick()                   
    {                                       
        Debug.Log("�����Exit");           
    }                                       
}                                           
