using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickChoose : MonoBehaviour
{
    /// <summary>
    /// �����Choose
    /// </summary>
    public void OnClick()
    {
        Debug.Log("�����Choose");
    }
}
